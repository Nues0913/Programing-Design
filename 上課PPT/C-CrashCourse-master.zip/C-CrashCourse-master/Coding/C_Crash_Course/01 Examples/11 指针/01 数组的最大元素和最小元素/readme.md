#### 程序：找出数组中的最大元素和最小元素

与程序的交互如下：

```c
Enter 5 numbers:9 5 2 7 8
Largest: 9
Smallest: 2
```

