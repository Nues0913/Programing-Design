#ifndef _STUDENT_H_
#define _STUDENT_H_

#define STR_LEN  20

typedef struct _student {
	char name[STR_LEN];
	char gender;
	char age;
}Student;
#endif