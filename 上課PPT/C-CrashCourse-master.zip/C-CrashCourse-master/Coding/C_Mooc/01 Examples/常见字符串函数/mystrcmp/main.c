

int main() {

	char* str1 = "Hello ";
	char* str2 = "Hello";

	printf("%d\n", mystrcmp(str1, str2));

	return 0;
}